package javaModel.service;

import javaModel.entity.User;

public interface UserService {
    public boolean login(User user);
}
