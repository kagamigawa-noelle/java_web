package javaModel.dao;

import javaModel.entity.User;

public interface UserDao {
    public boolean userLogin(User user);
}
